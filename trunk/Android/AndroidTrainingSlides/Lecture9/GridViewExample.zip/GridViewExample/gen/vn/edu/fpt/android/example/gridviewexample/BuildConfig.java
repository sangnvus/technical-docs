/** Automatically generated file. DO NOT MODIFY */
package vn.edu.fpt.android.example.gridviewexample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}