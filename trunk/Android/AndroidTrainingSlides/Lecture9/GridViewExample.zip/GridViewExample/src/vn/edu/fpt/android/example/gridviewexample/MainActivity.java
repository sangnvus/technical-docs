package vn.edu.fpt.android.example.gridviewexample;

import java.util.ArrayList;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Menu;
import android.widget.GridView;

public class MainActivity extends Activity {
	GridView gridView;
	ArrayList<MyGridItem> gridArray = new ArrayList<MyGridItem>();
	MyCustomGridViewAdapter customGridAdapter;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		//set grid view item
		  Bitmap homeIcon = 
				  BitmapFactory.decodeResource(this.getResources(), 
						  R.drawable.ic_launcher);

		  gridArray.add(new MyGridItem(homeIcon,"item 1"));
		  gridArray.add(new MyGridItem(homeIcon,"item 2"));
		  gridArray.add(new MyGridItem(homeIcon,"item 3"));
		  gridArray.add(new MyGridItem(homeIcon,"item 4"));
		  gridArray.add(new MyGridItem(homeIcon,"item 5"));
		  gridArray.add(new MyGridItem(homeIcon,"item 6"));
		  gridArray.add(new MyGridItem(homeIcon,"item 7"));
		  gridArray.add(new MyGridItem(homeIcon,"item 8"));
		  gridArray.add(new MyGridItem(homeIcon,"item 9"));

		  gridView = (GridView) findViewById(R.id.gridView1);
		  customGridAdapter = new MyCustomGridViewAdapter(this, R.layout.row_grid, gridArray);
		  gridView.setAdapter(customGridAdapter);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
