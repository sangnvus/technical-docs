package vn.edu.fpt.android.example.gridviewexample;

import android.graphics.Bitmap;

public class MyGridItem {
	public String txtTitle;
	public Bitmap Icon;
	
	public MyGridItem(Bitmap icon,String title)
	{
		txtTitle = title;
		Icon = icon;
	}
}
