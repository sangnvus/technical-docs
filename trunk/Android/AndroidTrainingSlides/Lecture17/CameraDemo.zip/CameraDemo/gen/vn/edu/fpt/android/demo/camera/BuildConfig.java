/** Automatically generated file. DO NOT MODIFY */
package vn.edu.fpt.android.demo.camera;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}