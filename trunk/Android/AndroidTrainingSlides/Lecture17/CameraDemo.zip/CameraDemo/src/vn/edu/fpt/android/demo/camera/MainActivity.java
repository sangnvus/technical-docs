package vn.edu.fpt.android.demo.camera;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.graphics.SurfaceTexture.OnFrameAvailableListener;
import android.hardware.Camera;
import android.hardware.Camera.CameraInfo;
import android.hardware.Camera.PictureCallback;
import android.hardware.Camera.PreviewCallback;
import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.TextureView;
import android.view.TextureView.SurfaceTextureListener;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity implements SurfaceHolder.Callback{

	private final static String LOG_TAG = "MainActivity";
	
	Button ButtonClick;
	int CAMERA_PIC_REQUEST = 1337; 
	
	
	
	 Camera camera;
	 SurfaceView surfaceView;
	 SurfaceHolder surfaceHolder;
	 boolean previewing = false;;

	@Override
	public void onCreate(Bundle savedInstanceState) {
	    super.onCreate(savedInstanceState);
	    setContentView(R.layout.activity_main);
	    
	    surfaceView = (SurfaceView)findViewById(R.id.surfaceview);
	    surfaceHolder = surfaceView.getHolder();
	    surfaceHolder.addCallback(this);
	    surfaceHolder.setType(SurfaceHolder.SURFACE_TYPE_PUSH_BUFFERS);
	      
	    ButtonClick =(Button) findViewById(R.id.captureFront);
	    ButtonClick.setOnClickListener(new OnClickListener (){
	        @Override
	        public void onClick(View view)
	        {
		        	
	            Intent cameraIntent = 
	            		new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
	            // request code

	            startActivityForResult(cameraIntent, CAMERA_PIC_REQUEST);
	        	 
	            
	            
		        	if(!previewing){
		        		camera = Camera.open();
		        		if (camera != null)
		        		{
		        			try {
		        				camera.setPreviewDisplay(surfaceHolder);
		        				camera.startPreview();
		        				camera.setPreviewCallback(new PreviewCallback() {
		        					public void onPreviewFrame(byte[] _data, Camera _camera) {
		        						// TODO Do something with the preview image.
		        						// process your data here
		        					}
	        					});
		        				previewing = true;
		        				ButtonClick.setText("Stop preview");
		        			} catch (IOException e) {
		        				// TODO Auto-generated catch block
		        				e.printStackTrace();
		        			}
		        		}
	        	     }else if(camera != null && previewing){
			        		camera.stopPreview();     
			        		camera.release();
			        		camera = null;
			        		previewing = false;
			        		ButtonClick.setText("Start preview");
	     		}
	        }
	    });
	    

	}

	/* take a picture from camera*/
	private void takePicture() {
		camera.takePicture(null, null, jpegCallback); 
	}
	
	PictureCallback jpegCallback = new PictureCallback() {
		public void onPictureTaken(byte[] _data, Camera _camera) {
			// TODO Do something with the image JPEG data.
			if (_data != null)
			{
				FileOutputStream fos;
				String fileName = "";
	            try {
	                if (fileName.equals("")) {
	                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyymmddhhmmss");
	                    String date = dateFormat.format(new Date());
	                    if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
	                        fileName = Environment.getExternalStorageDirectory().getAbsolutePath() + "/" + "picture" + date + ".jpg";
	                    }
	                    else{
	                        Toast.makeText(getApplicationContext(), "storing to internal " , Toast.LENGTH_LONG).show();
	                        //  fileName = Environment.getDataDirectory().getAbsolutePath() + "/" + "picture" + date + ".jpg";
	                        fileName = getApplicationContext().getFilesDir().getAbsolutePath()+ "/" + "unlocked" + date + ".jpg";
	                    }
	                    Toast.makeText(getApplicationContext(), "filename " + fileName, Toast.LENGTH_LONG).show();
	                    Log.d("camera","filename is : " + fileName);
	                }
	                Log.d("camera","coming here");
	                fos = new FileOutputStream(new File(fileName));
	                Log.d("camera","writing data");
	
	                fos.write(_data);
	                Log.d("camera","written data");
	                fos.close();
	            }  catch (IOException e) {
	                //do something about it
	                Log.d("camera","some exception"+ e);
	            }
	
	
			}
			else
				Toast.makeText(getApplicationContext(),
						"data  null " , 
						Toast.LENGTH_LONG).show();
		}
	};
		
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) 
	{
	    if( requestCode == 1337)
	    {
	    
	        Bitmap thumbnail = (Bitmap) data.getExtras().get("data");
	        /*
	        ImageView imgView = 
	        		(ImageView) findViewById(R.id.cameraPreview);
	        imgView.setImageBitmap(thumbnail);
	          */  
	        }
	    else 
	    {
	        Toast.makeText(this, "Picture NOt taken", Toast.LENGTH_LONG);
	    }
	    super.onActivityResult(requestCode, resultCode, data);
	}


	@Override
	public void surfaceChanged(SurfaceHolder holder, int format, int width,
			int height) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void surfaceCreated(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void surfaceDestroyed(SurfaceHolder holder) {
		// TODO Auto-generated method stub
		
	}
	
}
