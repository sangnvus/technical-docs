                                   -      SocketCoder Web Conferecing Project  -
                                                Video Chat Client/Server 



Requirements:

- You need to Install Visual Studio 2010 + Silverlight 4 

- for testing you need at least to make two sessions.



(C) SocketCoder.Com 2010