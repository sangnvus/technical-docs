                                   -      SocketCoder Web Conferencing Project  -
                                              Desktop Presenter Client/Server 



Requirements:

- You Need to Install Visual Studio 2010 + Silverlight 4 



(C) SocketCoder.Com 2010