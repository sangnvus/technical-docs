                     -     SocketCoder Web Conferencing Project  -
                             Voice Conferencing Client/Server 
                                          With Speex



Requirements:

- You need to Install Visual Studio 2010 + Silverlight 4 Tools
- for testing you need at least to make two sessions you will not hear your voice if you are working on one session

-------------------------------


(C) SocketCoder.Com 2010

