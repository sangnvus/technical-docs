﻿namespace java.net
{
    public class URL
    {
        internal java.io.InputStream openStream()
        {
            throw new System.NotImplementedException();
        }
    }
}
