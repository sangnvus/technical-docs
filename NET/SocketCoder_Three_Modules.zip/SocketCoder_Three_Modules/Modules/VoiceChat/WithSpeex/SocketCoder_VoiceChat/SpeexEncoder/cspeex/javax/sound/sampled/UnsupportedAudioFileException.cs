﻿namespace javax.sound.sampled
{
    public class UnsupportedAudioFileException : System.Exception
    {
        public UnsupportedAudioFileException(string message)
            : base(message)
        {
        }
    }
}
