﻿namespace java.io
{
    public class UTFDataFormatException : System.IO.IOException
    {
        public UTFDataFormatException(string message)
            : base(message)
        {
        }
    }
}
