                  -      SocketCoder Web Conferencing Project  -
                    Voice Conferencing Client/Server With G.711 



Requirements:

- You Need to Install Visual Studio 2010 + Silverlight 4 tools
- for testing you need at least to make two sessions you will not hear your voice if you are working on one session

-------------------------------


(C) SocketCoder.Com 2010

