package vn.com.usolv;

import vn.com.usolv.constants.Constants;
import vn.com.usolv.startedservice.HelloIntentService;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Messenger;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class StartedServiceActivity extends Activity {
    private Handler handler = new Handler() {
        public void handleMessage(Message message) {
            if (message.arg1 == RESULT_OK && message.obj != null) {
                Toast.makeText(StartedServiceActivity.this, "Downloaded " + message.obj.toString(), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(StartedServiceActivity.this, "Download failed.", Toast.LENGTH_LONG).show();
            }
        };
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        initComponents();
    }

    /**
     * Initialize UI components.
     */
    private void initComponents() {
        ((Button) findViewById(R.id.downloadButton)).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(StartedServiceActivity.this, HelloIntentService.class);

                // Create a new Messenger for the communication back
                intent.putExtra(Constants.MESSENGER_KEY, new Messenger(handler));
                intent.putExtra(Constants.URL_PATH_KEY, "http://developer.android.com/index.html");
                intent.putExtra(Constants.FILE_NAME, "/PracticeService/index.html");
                startService(intent);
            }
        });
    }
}
