package vn.com.usolv;

import vn.com.usolv.constants.Constants;
import vn.com.usolv.foreground.ForegroundService;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

/**
 * <p>
 * Example of explicitly starting and stopping the {@link ForegroundService}.
 * 
 * <p>
 * Note that this is implemented as an inner class only keep the sample all together; typically this code would appear
 * in some separate class.
 */
public class ForegroundServiceActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.foreground_service_controller);

        // Watch for button clicks.
        ((Button) findViewById(R.id.start_foreground)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Constants.ACTION_FOREGROUND);
                intent.setClass(ForegroundServiceActivity.this, ForegroundService.class);
                startService(intent);
            }
        });


        ((Button) findViewById(R.id.stop)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                stopService(new Intent(ForegroundServiceActivity.this, ForegroundService.class));
            }
        });
    }
}
