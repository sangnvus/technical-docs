package vn.com.usolv;

import vn.com.usolv.boundservice.MessengerService;
import vn.com.usolv.constants.Constants;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MessengerBoundServiceActivity extends Activity {
    /** Messenger for communicating with the service. */
    Messenger messenger = null;

    /** Flag indicating whether we have called bind on the service. */
    boolean bound;

    /**
     * Class for interacting with the main interface of the service.
     */
    private ServiceConnection serviceConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName className, IBinder binder) {
            // This is called when the connection with the service has been established, giving us the object we can use
            // to interact with the service. We are communicating with the service using a Messenger, so here we get a
            // client-side representation of that from the raw IBinder object.
            messenger = new Messenger(binder);
            bound = true;
        }

        public void onServiceDisconnected(ComponentName className) {
            // This is called when the connection with the service has been unexpectedly disconnected -- that is, its
            // process crashed.
            messenger = null;
            bound = false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.bound_service_messenger);
        initComponents();
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Bind to the service
        bindService(new Intent(this, MessengerService.class), serviceConnection, Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Unbind from the service
        if (bound) {
            unbindService(serviceConnection);
            bound = false;
        }
    }

    /**
     * Initialize UI components.
     */
    private void initComponents() {
        ((Button) findViewById(R.id.callServiceButton)).setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!bound) {
                    return;
                }

                // Create and send a message to the service, using a supported 'what' value
                Message message = Message.obtain(null, Constants.MSG_SAY_HELLO, 0, 0);

                try {
                    messenger.send(message);
                } catch (RemoteException e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
