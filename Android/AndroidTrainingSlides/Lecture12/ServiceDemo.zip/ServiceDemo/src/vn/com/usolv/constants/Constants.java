package vn.com.usolv.constants;

public class Constants {
    public static final String URL_PATH_KEY = "URL_PATH_KEY";
    public static final String MESSENGER_KEY = "MESSENGER_KEY";
    public static final String FILE_NAME = "FILE_NAME";

    /** Command to the service to display a message */
    public static final int MSG_SAY_HELLO = 1;
    
    public static final String ACTION_FOREGROUND = "vn.com.usolv.FOREGROUND";
}
