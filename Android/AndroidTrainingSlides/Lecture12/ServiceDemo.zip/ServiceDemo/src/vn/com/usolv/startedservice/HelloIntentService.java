package vn.com.usolv.startedservice;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import vn.com.usolv.constants.Constants;
import android.app.Activity;
import android.app.IntentService;
import android.content.Intent;
import android.os.Environment;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

/**
 * Sample implementation of IntentService.
 */
public class HelloIntentService extends IntentService {

    private int result = Activity.RESULT_CANCELED;

    /**
     * A constructor is required, and must call the super IntentService(String) constructor with a name for the worker
     * thread.
     */
    public HelloIntentService() {
        super(HelloIntentService.class.getName());
    }

    /**
     * The IntentService calls this method from the default worker thread with the intent that started the service. When
     * this method returns, IntentService stops the service, as appropriate.
     */
    @Override
    protected void onHandleIntent(Intent intent) {
        String urlPath = intent.getStringExtra(Constants.URL_PATH_KEY);
        String fileName = intent.getStringExtra(Constants.FILE_NAME);

        File output = new File(Environment.getExternalStorageDirectory(), fileName);
        if (output.exists()) {
            output.delete();
        }

        InputStreamReader reader = null;
        FileOutputStream fos = null;
        try {
            reader = new InputStreamReader(new URL(urlPath).openConnection().getInputStream());
            fos = new FileOutputStream(output.getPath());
            int next = -1;
            while ((next = reader.read()) != -1) {
                fos.write(next);
            }

            // Successful finished
            result = Activity.RESULT_OK;
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }

                if (fos != null) {
                    fos.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        if (intent.getExtras() != null) {
            Message message = Message.obtain();
            message.arg1 = result;
            message.obj = output.getAbsolutePath();

            try {
                ((Messenger) intent.getExtras().get(Constants.MESSENGER_KEY)).send(message);
            } catch (RemoteException re) {
                Log.e(getClass().getName(), "Failed in sending message", re);
            }
        }
    }
}
