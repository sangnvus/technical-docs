package vn.com.usolv.startedservice;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import vn.com.usolv.constants.Constants;
import android.app.Activity;
import android.app.Service;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Process;
import android.os.RemoteException;
import android.util.Log;
import android.widget.Toast;

public class HelloService extends Service {
    private ServiceHandler serviceHandler;

    private final class ServiceHandler extends Handler {
        public ServiceHandler(Looper looper) {
            super(looper);
        }

        @Override
        public void handleMessage(Message msg) {
            String urlPath = msg.getData().getString(Constants.URL_PATH_KEY);
            String fileName = msg.getData().getString(Constants.FILE_NAME);
            int result = Activity.RESULT_CANCELED;

            File output = new File(Environment.getExternalStorageDirectory(), fileName);
            if (output.exists()) {
                output.delete();
            }

            InputStreamReader reader = null;
            FileOutputStream fos = null;
            try {
                reader = new InputStreamReader(new URL(urlPath).openConnection().getInputStream());
                fos = new FileOutputStream(output.getPath());
                int next = -1;
                while ((next = reader.read()) != -1) {
                    fos.write(next);
                }

                // Successful finished
                result = Activity.RESULT_OK;
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                try {
                    if (reader != null) {
                        reader.close();
                    }

                    if (fos != null) {
                        fos.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            if (msg.obj != null) {
                Message message = Message.obtain();
                message.arg1 = result;
                message.obj = output.getAbsolutePath();

                try {
                    ((Messenger) msg.obj).send(message);
                } catch (RemoteException re) {
                    Log.e(getClass().getName(), "Failed in sending message", re);
                }
            }

            stopSelf(msg.arg1);
        }
    }

    @Override
    public void onCreate() {
        HandlerThread thread = new HandlerThread("HelloService", Process.THREAD_PRIORITY_BACKGROUND);
        thread.start();

        serviceHandler = new ServiceHandler(thread.getLooper());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(this, "Service starting", Toast.LENGTH_SHORT).show();

        Message message = serviceHandler.obtainMessage();
        message.arg1 = startId;
        message.obj = intent.getExtras().get(Constants.MESSENGER_KEY);

        Bundle requestData = new Bundle();
        requestData.putString(Constants.URL_PATH_KEY, intent.getStringExtra(Constants.URL_PATH_KEY));
        requestData.putString(Constants.FILE_NAME, intent.getStringExtra(Constants.FILE_NAME));
        message.setData(requestData);

        serviceHandler.sendMessage(message);

        // If we get killed, after returning from here, restart
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        Toast.makeText(this, "Service done", Toast.LENGTH_SHORT).show();
    }
}
